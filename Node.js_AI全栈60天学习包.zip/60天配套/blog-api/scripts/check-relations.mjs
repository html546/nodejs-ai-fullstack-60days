import { PrismaClient } from '@prisma/client';

const prisma = new PrismaClient();
try {
  const posts = await prisma.post.findMany({
    include: { author: { select: { id: true, name: true } } },
    orderBy: { createdAt: 'desc' },
  });
  console.log(posts);
} catch (error) {
  console.error('关系查询失败：', error instanceof Error ? error.name : 'UnknownError');
  process.exitCode = 1;
} finally {
  await prisma.$disconnect();
}
