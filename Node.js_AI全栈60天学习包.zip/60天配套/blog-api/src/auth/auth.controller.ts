import { Body, Controller, Header, HttpCode, Post } from '@nestjs/common';
import { Transform } from 'class-transformer';
import { IsEmail, IsString, Length, Matches, MaxLength } from 'class-validator';
import { AuthService } from './auth.service';

class CredentialsDto {
  @Transform(({ value }) => typeof value === 'string' ? value.trim().toLowerCase() : value)
  @IsEmail() @MaxLength(254)
  email!: string;

  @IsString() @Length(12, 128)
  password!: string;
}

class RegisterDto extends CredentialsDto {
  @Transform(({ value }) => typeof value === 'string' ? value.trim() : value)
  @IsString() @Length(1, 80) @Matches(/\S/)
  name!: string;
}

class RefreshDto {
  @IsString() @Matches(/^[A-Za-z0-9_-]{43}$/)
  refreshToken!: string;
}

@Controller('auth')
export class AuthController {
  constructor(private readonly auth: AuthService) {}

  @Post('register') @Header('Cache-Control', 'no-store')
  register(@Body() dto: RegisterDto) {
    return this.auth.register(dto.email, dto.password, dto.name);
  }

  @Post('login') @HttpCode(200) @Header('Cache-Control', 'no-store')
  login(@Body() dto: CredentialsDto) { return this.auth.login(dto.email, dto.password); }

  @Post('refresh') @HttpCode(200) @Header('Cache-Control', 'no-store')
  refresh(@Body() dto: RefreshDto) { return this.auth.refresh(dto.refreshToken); }

  @Post('logout') @HttpCode(204) @Header('Cache-Control', 'no-store')
  async logout(@Body() dto: RefreshDto) { await this.auth.logout(dto.refreshToken); }
}
