import { ConflictException, Injectable, UnauthorizedException } from '@nestjs/common';
import { JwtService } from '@nestjs/jwt';
import { Prisma } from '@prisma/client';
import { createHash, randomBytes } from 'node:crypto';
import * as argon2 from 'argon2';
import { PrismaService } from '../prisma/prisma.service';

const hashToken = (token: string) => createHash('sha256').update(token).digest('hex');
const refreshLifetime = 7 * 24 * 60 * 60 * 1000;

@Injectable()
export class AuthService {
  constructor(private readonly db: PrismaService, private readonly jwt: JwtService) {}

  async register(email: string, password: string, name: string) {
    const passwordHash = await argon2.hash(password, { type: argon2.argon2id });
    try {
      return await this.db.user.create({
        data: { email, passwordHash, author: { create: { name } } },
        select: { id: true, email: true, authorId: true },
      });
    } catch (error) {
      if (error instanceof Prisma.PrismaClientKnownRequestError && error.code === 'P2002') {
        throw new ConflictException('邮箱已注册');
      }
      throw error;
    }
  }

  async login(email: string, password: string) {
    const user = await this.db.user.findUnique({
      where: { email }, select: { id: true, passwordHash: true },
    });
    if (!user || !await argon2.verify(user.passwordHash, password)) {
      throw new UnauthorizedException('邮箱或密码错误');
    }
    return this.db.$transaction(tx => this.issue(tx, user.id));
  }

  private async issue(tx: Prisma.TransactionClient, userId: number) {
    const refreshToken = randomBytes(32).toString('base64url');
    const accessToken = await this.jwt.signAsync({ sub: String(userId) });
    await tx.refreshSession.create({ data: {
      tokenHash: hashToken(refreshToken), userId,
      expiresAt: new Date(Date.now() + refreshLifetime),
    } });
    return { accessToken, refreshToken, expiresIn: 600 };
  }

  async refresh(refreshToken: string) {
    const tokenHash = hashToken(refreshToken);
    return this.db.$transaction(async tx => {
      const session = await tx.refreshSession.findUnique({ where: { tokenHash } });
      if (!session) throw new UnauthorizedException('请重新登录');
      const consumed = await tx.refreshSession.deleteMany({
        where: { tokenHash, expiresAt: { gt: new Date() } },
      });
      if (consumed.count !== 1) throw new UnauthorizedException('请重新登录');
      return this.issue(tx, session.userId);
    });
  }

  async logout(refreshToken: string) {
    await this.db.refreshSession.deleteMany({ where: { tokenHash: hashToken(refreshToken) } });
  }
}
