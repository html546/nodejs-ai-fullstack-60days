import { CanActivate, ExecutionContext, Injectable, UnauthorizedException } from '@nestjs/common';
import { JwtService } from '@nestjs/jwt';
import type { Request } from 'express';

export type AuthRequest = Request & { user?: { sub: string } };

@Injectable()
export class JwtAuthGuard implements CanActivate {
  constructor(private readonly jwt: JwtService) {}
  async canActivate(context: ExecutionContext) {
    const req = context.switchToHttp().getRequest<AuthRequest>();
    const token = /^Bearer ([^\s]+)$/i.exec(req.headers.authorization ?? '')?.[1];
    if (!token) throw new UnauthorizedException();
    try {
      const claims = await this.jwt.verifyAsync<{ sub?: unknown; exp?: unknown }>(token);
      if (typeof claims.sub !== 'string' || !claims.sub || typeof claims.exp !== 'number') {
        throw new UnauthorizedException();
      }
      req.user = { sub: claims.sub };
      return true;
    } catch {
      throw new UnauthorizedException();
    }
  }
}
