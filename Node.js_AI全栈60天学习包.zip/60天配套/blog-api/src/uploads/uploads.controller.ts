// src/uploads/uploads.controller.ts（完整文件）
import {
  BadRequestException, Controller, Param, ParseIntPipe, PayloadTooLargeException,
  Post, Req, UploadedFile, UseGuards, UseInterceptors,
} from '@nestjs/common';
import { FileInterceptor } from '@nestjs/platform-express';
import { JwtAuthGuard, type AuthRequest } from '../auth/jwt-auth.guard';
import { safeUploadName } from './upload.validation';
import { UploadsService } from './uploads.service';

@Controller('posts')
export class UploadsController {
  constructor(private readonly uploads: UploadsService) {}

  @Post(':id/cover')
  @UseGuards(JwtAuthGuard)
  @UseInterceptors(FileInterceptor('cover', {
    dest: process.env.UPLOAD_ROOT ?? './var/quarantine',
    limits: { fileSize: 5 * 1024 * 1024, files: 1, fields: 10 },
    fileFilter: (_req, file, cb) => {
      try { safeUploadName(file.mimetype, file.originalname); cb(null, true); }
      catch { cb(new BadRequestException('不支持的文件类型'), false); }
    },
  }))
  async cover(@Param('id', ParseIntPipe) id: number,
    @UploadedFile() file: Express.Multer.File, @Req() req: AuthRequest) {
    if (!file) throw new BadRequestException('必须上传 cover');
    if (file.size > 5 * 1024 * 1024) throw new PayloadTooLargeException();
    return this.uploads.attachCover(id, file, req.user!.sub);
  }
}
