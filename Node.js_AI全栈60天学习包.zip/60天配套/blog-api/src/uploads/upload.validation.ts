import { BadRequestException } from '@nestjs/common';
import { randomUUID } from 'node:crypto';
import { extname } from 'node:path';

const allowed = new Map([
  ['image/jpeg', '.jpg'], ['image/png', '.png'], ['image/webp', '.webp'],
]);

export function safeUploadName(mimetype: string, originalname: string) {
  const expected = allowed.get(mimetype);
  const extension = extname(originalname).toLowerCase();
  if (!expected || extension !== expected) throw new BadRequestException('不支持的文件类型');
  return `${randomUUID()}${expected}`;
}
