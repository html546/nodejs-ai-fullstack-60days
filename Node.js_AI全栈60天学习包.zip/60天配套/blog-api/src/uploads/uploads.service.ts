import { BadRequestException, ForbiddenException, Injectable, NotFoundException } from '@nestjs/common';
import { promises as fs } from 'node:fs';
import { join, resolve } from 'node:path';
import { PrismaService } from '../prisma/prisma.service';
import { safeUploadName } from './upload.validation';

@Injectable()
export class UploadsService {
  private readonly root = resolve(process.env.UPLOAD_ROOT ?? './var/quarantine');

  constructor(private readonly prisma: PrismaService) {}

  async attachCover(postId: number, file: Express.Multer.File, sub: string) {
    const ownerId = Number(sub);
    if (!Number.isSafeInteger(ownerId) || ownerId < 1) throw new BadRequestException();
    const post = await this.prisma.post.findUnique({ where: { id: postId } });
    if (!post) throw new NotFoundException();
    if (post.authorId !== ownerId) throw new ForbiddenException();

    const storedName = safeUploadName(file.mimetype, file.originalname);
    await fs.mkdir(this.root, { recursive: true, mode: 0o700 });
    const source = join(this.root, file.filename);
    const target = join(this.root, storedName);
    try {
      await fs.rename(source, target);
      return await this.prisma.postCover.create({
        data: { postId, ownerId, storedName, mimeType: file.mimetype, byteSize: file.size },
        select: { id: true, postId: true, mimeType: true, byteSize: true, createdAt: true },
      });
    } catch (error) {
      await fs.unlink(source).catch(() => undefined);
      await fs.unlink(target).catch(() => undefined);
      throw error;
    }
  }
}
