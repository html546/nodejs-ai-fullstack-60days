export interface Post {
  id: number;
  title: string;
  body: string;
  authorId: number;
  createdAt: Date;
  publishedAt: Date | null;
}
