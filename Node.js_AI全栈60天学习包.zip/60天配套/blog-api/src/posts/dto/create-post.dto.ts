import { Transform } from 'class-transformer';
import { IsInt, IsString, Length, Max, Min } from 'class-validator';

export class CreatePostDto {
  @Transform(({ value }) => typeof value === 'string' ? value.trim() : value)
  @IsString()
  @Length(1, 120)
  title!: string;

  @IsString()
  @Length(1, 5000)
  body!: string;

  @IsInt()
  @Min(1)
  @Max(2_147_483_647)
  authorId!: number;
}
