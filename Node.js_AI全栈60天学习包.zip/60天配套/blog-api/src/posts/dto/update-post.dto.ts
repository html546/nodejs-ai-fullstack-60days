import { Transform } from 'class-transformer';
import { IsString, Length, ValidateIf } from 'class-validator';

export class UpdatePostDto {
  @ValidateIf((_object, value) => value !== undefined)
  @Transform(({ value }) => typeof value === 'string' ? value.trim() : value)
  @IsString()
  @Length(1, 120)
  title?: string;

  @ValidateIf((_object, value) => value !== undefined)
  @IsString()
  @Length(1, 5000)
  body?: string;
}
