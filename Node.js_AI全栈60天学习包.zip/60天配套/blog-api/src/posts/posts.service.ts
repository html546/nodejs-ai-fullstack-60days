import { BadRequestException, Injectable, NotFoundException } from '@nestjs/common';
import { Prisma } from '@prisma/client';
import { PrismaService } from '../prisma/prisma.service';
import type { CreatePostDto } from './dto/create-post.dto';
import type { UpdatePostDto } from './dto/update-post.dto';
import type { Post } from './post';

@Injectable()
export class PostsService {
  constructor(private readonly prisma: PrismaService) {}

  private assertId(id: number) {
    if (!Number.isInteger(id) || id < 1 || id > 2_147_483_647) {
      throw new BadRequestException('文章 ID 超出范围');
    }
  }

  async list(): Promise<Post[]> {
    return this.prisma.post.findMany({ orderBy: { id: 'asc' } });
  }

  async get(id: number): Promise<Post> {
    this.assertId(id);
    const post = await this.prisma.post.findUnique({ where: { id } });
    if (!post) throw new NotFoundException('文章不存在');
    return post;
  }

  async create(dto: CreatePostDto): Promise<Post> {
    try {
      return await this.prisma.post.create({
        data: { title: dto.title, body: dto.body, authorId: dto.authorId },
      });
    } catch (error) {
      if (error instanceof Prisma.PrismaClientKnownRequestError && error.code === 'P2003') {
        throw new NotFoundException('作者不存在');
      }
      throw error;
    }
  }

  async update(id: number, dto: UpdatePostDto): Promise<Post> {
    if (dto.title === undefined && dto.body === undefined) {
      throw new BadRequestException('请至少提供 title 或 body');
    }
    this.assertId(id);
    const data: { title?: string; body?: string } = {};
    if (dto.title !== undefined) data.title = dto.title;
    if (dto.body !== undefined) data.body = dto.body;
    try {
      return await this.prisma.post.update({ where: { id }, data });
    } catch (error) {
      if (error instanceof Prisma.PrismaClientKnownRequestError && error.code === 'P2025') {
        throw new NotFoundException('文章不存在');
      }
      throw error;
    }
  }

  async delete(id: number): Promise<{ id: number }> {
    this.assertId(id);
    try {
      return await this.prisma.post.delete({ where: { id }, select: { id: true } });
    } catch (error) {
      if (error instanceof Prisma.PrismaClientKnownRequestError && error.code === 'P2025') {
        throw new NotFoundException('文章不存在');
      }
      throw error;
    }
  }
}
