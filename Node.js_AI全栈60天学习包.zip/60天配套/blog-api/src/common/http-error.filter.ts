import { ArgumentsHost, Catch, ExceptionFilter, HttpException, Logger } from '@nestjs/common';
import type { Response } from 'express';

@Catch()
export class HttpErrorFilter implements ExceptionFilter {
  private readonly logger = new Logger(HttpErrorFilter.name);

  catch(exception: unknown, host: ArgumentsHost) {
    const res = host.switchToHttp().getResponse<Response>();
    if (res.headersSent) {
      res.end();
      return;
    }

    let statusCode = 500;
    let message: string | string[] = '服务暂时不可用';
    if (exception instanceof HttpException) {
      statusCode = exception.getStatus();
      const payload = exception.getResponse();
      message = typeof payload === 'string'
        ? payload
        : (payload as { message?: string | string[] }).message ?? exception.message;
    } else {
      const name = exception instanceof Error ? exception.name : 'UnknownError';
      this.logger.error(`Unhandled exception (${name})`);
    }

    res.status(statusCode).json({ error: { statusCode, message } });
  }
}
