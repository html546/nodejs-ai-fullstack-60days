import {
  CallHandler, ExecutionContext, Injectable, NestInterceptor,
} from '@nestjs/common';
import { randomUUID } from 'node:crypto';
import { Observable, tap } from 'rxjs';

@Injectable()
export class LoggingInterceptor implements NestInterceptor {
  intercept(ctx: ExecutionContext, next: CallHandler): Observable<unknown> {
    const req = ctx.switchToHttp().getRequest();
    const requestId = randomUUID();
    const started = Date.now();
    req.requestId = requestId; // 供异常过滤器复用同一个 ID
    return next.handle().pipe(
      tap({
        next: () => this.write(req, requestId, Date.now() - started),
        error: (error) => {
          // 只记录错误类别与 requestId，不输出 error 对象（可能含配置/凭据）
          this.write(req, requestId, Date.now() - started, error?.constructor?.name ?? 'Error');
        },
      }),
    );
  }

  private write(req: any, requestId: string, durationMs: number, error?: string) {
    // eslint-disable-next-line no-console -- 教学最小实现；生产换成 Pino 等结构化日志
    console.log(JSON.stringify({
      requestId,
      method: req.method,
      route: req.route?.path ?? req.url.split('?')[0],
      statusCode: req.res?.statusCode ?? (error ? 500 : 200),
      durationMs,
      ...(error ? { error } : {}),
    }));
  }
}
