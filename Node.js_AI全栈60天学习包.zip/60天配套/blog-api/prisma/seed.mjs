import { PrismaClient } from '@prisma/client';

const prisma = new PrismaClient();
try {
  await prisma.$transaction(async (tx) => {
    await tx.author.upsert({
      where: { id: 1 },
      update: { name: 'Ada' },
      create: { id: 1, name: 'Ada' },
    });
    await tx.$queryRaw`
      SELECT setval(
        pg_get_serial_sequence('authors', 'id'),
        (SELECT COALESCE(MAX(id), 1) FROM authors),
        true
      )
    `;
  });
  console.log('已准备作者 Ada（ID 1）');
} catch (error) {
  console.error('Seed 失败：', error instanceof Error ? error.name : 'UnknownError');
  process.exitCode = 1;
} finally {
  await prisma.$disconnect();
}
