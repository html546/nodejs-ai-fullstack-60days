# 博客 API（第 16–45 天源码快照）

本目录的 `src/` 文件直接从主教材对应天的完整代码块抽取，按「最后出现的版本」保留（例如 `posts.service.ts` 取第 27 天替换后的数据库版）。

**这不是开箱即用的工程**：教材采用「先建 `nest new` 脚手架，再按天替换/追加文件」的写法，所以这里没有 `package.json`、`.env`、`prisma/schema.prisma` 的迁移历史。要运行请按正文顺序补齐：

1. `nest new blog-api`，依赖见正文环境表（Nest 11、Prisma 6.19.x、PostgreSQL 16）。
2. 按第 21/25 天建立数据库与 `schema.prisma`，执行 `npx prisma migrate dev`。
3. 按第 16–20 天把 `posts/` 与 `common/` 放进 `src/`；第 27/28 天用这里的数据库版替换内存版。
4. 第 32–34 天补 `auth/`（含 `.env` 的 JWT 密钥），第 39 天补 `uploads/`，第 45 天补 `logging.interceptor.ts`。
5. 每天按正文的验收命令自测；片段类步骤（如 `posts.service.ts 中增加 listPage`）请照正文手工插入。

文件顶部的来源信息见主教材对应天。不要把真实 `.env`、密钥或生产数据放进本目录。
