# 博客 API（第 16–45 天源码快照）

本目录的 `src/` 文件直接从主教材对应天的完整代码块抽取，按「最后出现的版本」保留（例如 `posts.service.ts` 取第 27 天替换后的数据库版）。

**这不是开箱即用的工程**：教材采用「先建 `nest new` 脚手架，再按天替换/追加文件」的写法。已收录与未收录的边界如下。

## 已收录（src/ 下）

- `posts/`：`post.ts`、`posts.service.ts`、`posts.controller.ts`、`posts.module.ts`、`dto/create-post.dto.ts`、`dto/update-post.dto.ts`
- `prisma/`：`prisma.service.ts`、`prisma.module.ts`
- `auth/`：`auth.controller.ts`、`auth.service.ts`、`jwt-auth.guard.ts`
- `common/`：`data.interceptor.ts`、`http-error.filter.ts`、`logging.interceptor.ts`、`trace.middleware.ts`
- `uploads/`：`uploads.controller.ts`、`uploads.service.ts`、`uploads.module.ts`、`upload.validation.ts`
- `prisma/seed.mjs`、`scripts/check-relations.mjs`

（第 39 天的三个 `uploads/` 文件与 `post.ts` 在 v2 补齐，此前快照缺这些被 import 的本地模块，直接 `tsc` 会报 `Cannot find module`。）

## 未收录，需按正文补齐

- 脚手架：`package.json`、`tsconfig.json`、`nest-cli.json`、`.env`、`main.ts`、`app.module.ts`
- Prisma：`schema.prisma`、`prisma/migrations/`（含第 25/26/33/34/39 天各次迁移）
- 第 33 天起的权限改造：`post-policy.ts`、`createForActor` / `removeForActor` / `updateForActor` / `publishForActor`、Guard 与 DTO 调整都是**追加片段**，本快照的 `posts.service.ts` 仍是第 27 天版本，不能直接用它跑第 33 天验收
- 第 36–38 天的 Redis 缓存与队列模块、第 41–45 天的 Docker/CI/日志配置
- 各类 npm 依赖与数据库/Redis 实例

## 运行顺序

1. `nest new blog-api`，依赖见正文环境表（Nest 11、Prisma 6.19.x、PostgreSQL 16）。
2. 按第 21/25 天建立数据库与 `schema.prisma`，执行 `npx prisma migrate dev`。
3. 按第 16–20 天把 `posts/` 与 `common/` 放进 `src/`；第 27/28 天用这里的数据库版替换内存版。
4. 第 32–34 天补 `auth/`（含 `.env` 的 JWT 密钥）与第 33 天权限片段，第 39 天补 `uploads/`，第 45 天补 `logging.interceptor.ts`。
5. 每天按正文的验收命令自测；片段类步骤（如 `posts.service.ts 中增加 listPage`）请照正文手工插入。

文件顶部的来源信息见主教材对应天。不要把真实 `.env`、密钥或生产数据放进本目录。
