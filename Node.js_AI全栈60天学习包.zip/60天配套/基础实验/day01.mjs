const tasks = [
  { id: 't1', title: '整理需求', status: 'todo' },
  { id: 't2', title: '准备示例', status: 'doing' },
]
let doneCount = 0

for (const task of tasks) {
  if (task.status === 'done') {
    doneCount += 1
  }
  console.log(`[${task.status}] ${task.title}`)
}
console.log(`已完成 ${doneCount} / ${tasks.length}`)
