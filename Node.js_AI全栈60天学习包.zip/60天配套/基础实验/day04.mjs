import { EventEmitter } from 'node:events'
import { createReadStream, createWriteStream } from 'node:fs'
import { pipeline } from 'node:stream'

const board = new EventEmitter()
const target = 'data/tasks.backup.json'

board.on('backup:done', (file) => {
  console.log(`已备份 ${file}`)
})

const label = '任务'
const bytes = Buffer.from(label, 'utf8')
console.log(label.length, bytes.length, bytes.toString('utf8'))

pipeline(
  createReadStream('data/tasks.json'),
  createWriteStream(target),
  (error) => {
    if (error) {
      console.error('备份失败：', error.code ?? error.message)
      process.exitCode = 1
      return
    }
    board.emit('backup:done', target)
  },
)
