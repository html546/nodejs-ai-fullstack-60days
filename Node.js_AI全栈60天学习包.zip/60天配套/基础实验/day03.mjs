import { existsSync, mkdirSync, readFileSync, writeFileSync } from 'node:fs'
import path from 'node:path'
import os from 'node:os'

const seed = [{ id: 't1', title: '整理需求', status: 'todo' }]
const dataDir = path.resolve('data')
const file = path.join(dataDir, 'tasks.json')

try {
  mkdirSync(dataDir, { recursive: true })
  if (!existsSync(file)) {
    writeFileSync(file, JSON.stringify(seed, null, 2), 'utf8')
  }
  const text = readFileSync(file, 'utf8')
  const tasks = JSON.parse(text)
  if (!Array.isArray(tasks)) {
    throw new Error('任务文件需要包含数组')
  }
  console.log(`任务数 ${tasks.length}`)
  console.log(`系统 ${os.platform()}，文件 ${file}`)
} catch (error) {
  console.error('读取任务失败：', error.message)
  process.exitCode = 1
}
