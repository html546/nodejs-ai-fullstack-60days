import { EventEmitter } from 'node:events'

const board = new EventEmitter()
board.on('ready', () => console.log('2 同步事件'))

console.log('1 开始')
setTimeout(() => console.log('6 定时器'), 0)
board.emit('ready')
Promise.resolve('4 Promise 已兑现').then((message) => {
  console.log(message)
})
queueMicrotask(() => console.log('5 普通微任务'))
console.log('3 同步结束')
