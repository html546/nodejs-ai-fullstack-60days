import pc from 'picocolors'
import { countByStatus } from './task-stats.mjs'

const colors = pc.createColors(false)
const tasks = [
  { id: 't1', title: '整理需求', status: 'todo' },
  { id: 't2', title: '准备示例', status: 'done' },
]
const doneCount = countByStatus(tasks, 'done')
console.log(colors.green(`已完成 ${doneCount} / ${tasks.length}`))
