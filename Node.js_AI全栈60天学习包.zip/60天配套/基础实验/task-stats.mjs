export function countByStatus(tasks, status) {
  let count = 0
  for (const task of tasks) {
    if (task.status === status) {
      count += 1
    }
  }
  return count
}
