import { randomBytes, scrypt, timingSafeEqual } from 'node:crypto';
import { promisify } from 'node:util';
import { Transform } from 'class-transformer';
import { IsEmail, IsString, MaxLength, MinLength } from 'class-validator';
import {
  Body, CanActivate, ConflictException, Controller, ExecutionContext,
  HttpCode, Injectable, Post, UnauthorizedException,
} from '@nestjs/common';
import { JwtService } from '@nestjs/jwt';
import { Prisma } from '@prisma/client';
import { PrismaService } from './prisma.service';

const derive = promisify(scrypt);

class Credentials {
  @Transform(({ value }) => typeof value === 'string' ? value.trim().toLowerCase() : value)
  @IsEmail() @MaxLength(254)
  email!: string;

  @IsString() @MinLength(12) @MaxLength(128)
  password!: string;
}

async function hashPassword(password: string) {
  const salt = randomBytes(16).toString('hex');
  return `${salt}:${(await derive(password, salt, 64)).toString('hex')}`;
}

async function matches(password: string, stored: string) {
  const [salt, hex] = stored.split(':');
  if (!salt || !hex) return false;
  const expected = Buffer.from(hex, 'hex');
  const actual = await derive(password, salt, 64);
  return expected.length === actual.length && timingSafeEqual(expected, actual);
}

@Controller('auth')
export class AuthController {
  constructor(private db: PrismaService, private jwt: JwtService) {}

  @Post('register')
  async register(@Body() body: Credentials) {
    try {
      return await this.db.user.create({
        data: { email: body.email, passwordHash: await hashPassword(body.password) },
        select: { id: true, email: true },
      });
    } catch (error) {
      if (error instanceof Prisma.PrismaClientKnownRequestError && error.code === 'P2002') {
        throw new ConflictException('此邮箱已注册');
      }
      throw error;
    }
  }

  @Post('login') @HttpCode(200)
  async login(@Body() body: Credentials) {
    const user = await this.db.user.findUnique({ where: { email: body.email } });
    if (!user || !await matches(body.password, user.passwordHash)) {
      throw new UnauthorizedException('邮箱或密码有误');
    }
    return { accessToken: await this.jwt.signAsync({ sub: user.id }) };
  }
}

@Injectable()
export class BearerGuard implements CanActivate {
  constructor(private jwt: JwtService) {}

  async verify(token: string): Promise<{ sub: string }> {
    try {
      const claims = await this.jwt.verifyAsync<{ sub?: string }>(token);
      if (typeof claims.sub !== 'string' || !claims.sub) throw new Error('missing sub');
      return { sub: claims.sub };
    } catch {
      throw new UnauthorizedException('请重新登录');
    }
  }

  async canActivate(ctx: ExecutionContext) {
    const req = ctx.switchToHttp().getRequest();
    const token = /^Bearer (\S+)$/i.exec(req.headers.authorization ?? '')?.[1];
    if (!token) throw new UnauthorizedException('请登录');
    req.user = await this.verify(token);
    return true;
  }
}
