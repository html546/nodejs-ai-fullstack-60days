import {
  Body, CanActivate, ConflictException, Controller, ExecutionContext,
  ForbiddenException, Get, Injectable, NotFoundException, Param, Post, Req, UseGuards,
} from '@nestjs/common';
import { Prisma, TeamRole } from '@prisma/client';
import { Transform } from 'class-transformer';
import { IsEmail, IsString, Matches, MaxLength } from 'class-validator';
import { BearerGuard } from './auth';
import { PrismaService } from './prisma.service';

export type ActorRequest = { user: { sub: string }; teamRole: TeamRole };

class TeamName {
  @IsString() @Matches(/\S/) @MaxLength(80)
  name!: string;
}

class MemberEmail {
  @Transform(({ value }) => typeof value === 'string' ? value.trim().toLowerCase() : value)
  @IsEmail() @MaxLength(254)
  email!: string;
}

@Injectable()
export class TeamAccess {
  constructor(private db: PrismaService) {}

  async requireMember(teamId: string, userId: string) {
    const row = await this.db.membership.findUnique({
      where: { teamId_userId: { teamId, userId } },
    });
    if (!row) throw new ForbiddenException('你不属于该团队');
    return row;
  }
}

@Injectable()
export class TeamGuard implements CanActivate {
  constructor(private access: TeamAccess) {}

  async canActivate(ctx: ExecutionContext) {
    const req = ctx.switchToHttp().getRequest<ActorRequest & { params: { teamId: string } }>();
    req.teamRole = (await this.access.requireMember(req.params.teamId, req.user.sub)).role;
    return true;
  }
}

@Controller('teams')
@UseGuards(BearerGuard)
export class TeamsController {
  constructor(private db: PrismaService) {}

  @Get()
  async list(@Req() req: ActorRequest) {
    const rows = await this.db.membership.findMany({
      where: { userId: req.user.sub }, include: { team: true }, orderBy: { teamId: 'asc' },
    });
    return rows.map(({ team, role }) => ({ ...team, role }));
  }

  @Post()
  create(@Req() req: ActorRequest, @Body() body: TeamName) {
    return this.db.team.create({ data: {
      name: body.name.trim(), memberships: { create: { userId: req.user.sub, role: 'owner' } },
    } });
  }

  @Post(':teamId/members') @UseGuards(TeamGuard)
  async add(@Req() req: ActorRequest, @Param('teamId') teamId: string, @Body() body: MemberEmail) {
    if (req.teamRole !== 'owner') throw new ForbiddenException('只有所有者可以添加成员');
    const user = await this.db.user.findUnique({ where: { email: body.email } });
    if (!user) throw new NotFoundException('请先注册');
    try {
      return await this.db.membership.create({ data: { teamId, userId: user.id } });
    } catch (error) {
      if (error instanceof Prisma.PrismaClientKnownRequestError && error.code === 'P2002') {
        throw new ConflictException('该账号已是成员');
      }
      throw error;
    }
  }
}
