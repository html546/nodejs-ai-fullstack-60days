import {
  BadRequestException, Body, ConflictException, Controller, Delete, Get,
  HttpCode, Injectable, NotFoundException, Param, Patch, Post, UseGuards,
} from '@nestjs/common';
import { IsEnum, IsString, Matches, MaxLength, ValidateIf } from 'class-validator';
import { Prisma, TaskStatus } from '@prisma/client';
import { BearerGuard } from './auth';
import { TeamGuard } from './teams';
import { PrismaService } from './prisma.service';

function mapWriteError(error: unknown): never {
  if (error instanceof Prisma.PrismaClientKnownRequestError) {
    if (error.code === 'P2025') throw new NotFoundException('当前范围内找不到记录');
    if (error.code === 'P2003') throw new ConflictException('关联记录阻止了本次写入');
  }
  throw error;
}

const taskFields = { id: true, title: true, status: true, teamId: true, projectId: true } as const;

@Injectable()
export class BoardService {
  constructor(private db: PrismaService) {}

  async requireProject(teamId: string, projectId: string) {
    const project = await this.db.project.findUnique({ where: { id: projectId, teamId } });
    if (!project) throw new NotFoundException('项目不存在');
    return project;
  }

  listProjects(teamId: string) {
    return this.db.project.findMany({ where: { teamId }, orderBy: { id: 'asc' } });
  }

  createProject(teamId: string, name: string) {
    return this.db.project.create({ data: { teamId, name } });
  }

  renameProject(teamId: string, id: string, name: string) {
    return this.db.project.update({ where: { id, teamId }, data: { name } }).catch(mapWriteError);
  }

  async deleteProject(teamId: string, id: string) {
    await this.db.project.delete({ where: { id, teamId } }).catch(mapWriteError);
  }

  async createTask(teamId: string, projectId: string, title: string) {
    await this.requireProject(teamId, projectId);
    return this.db.task.create({
      data: { teamId, projectId, title }, select: taskFields,
    }).catch(mapWriteError);
  }

  async getTask(teamId: string, projectId: string, id: string) {
    const task = await this.db.task.findUnique({
      where: { id, teamId, projectId }, select: taskFields,
    });
    if (!task) throw new NotFoundException('任务不存在');
    return task;
  }

  updateTask(teamId: string, projectId: string, id: string, body: ChangeTask) {
    const data = { title: body.title?.trim(), status: body.status };
    if (data.title === undefined && data.status === undefined) {
      throw new BadRequestException('请提供 title 或 status');
    }
    return this.db.task.update({
      where: { id, teamId, projectId }, data, select: taskFields,
    }).catch(mapWriteError);
  }

  async deleteTask(teamId: string, projectId: string, id: string) {
    await this.db.task.delete({ where: { id, teamId, projectId } }).catch(mapWriteError);
  }
}

class ProjectName {
  @IsString() @Matches(/\S/) @MaxLength(80)
  name!: string;
}

class NewTask {
  @IsString() @Matches(/\S/) @MaxLength(120)
  title!: string;
}

class ChangeTask {
  @ValidateIf((_object, value) => value !== undefined)
  @IsString() @Matches(/\S/) @MaxLength(120)
  title?: string;

  @ValidateIf((_object, value) => value !== undefined)
  @IsEnum(TaskStatus)
  status?: TaskStatus;
}

@Controller('teams/:teamId/projects')
@UseGuards(BearerGuard, TeamGuard)
export class ProjectsController {
  constructor(private board: BoardService) {}

  @Get()
  list(@Param('teamId') t: string) { return this.board.listProjects(t); }

  @Post()
  create(@Param('teamId') t: string, @Body() body: ProjectName) {
    return this.board.createProject(t, body.name.trim());
  }

  @Get(':projectId')
  get(@Param('teamId') t: string, @Param('projectId') p: string) {
    return this.board.requireProject(t, p);
  }

  @Patch(':projectId')
  rename(@Param('teamId') t: string, @Param('projectId') p: string, @Body() body: ProjectName) {
    return this.board.renameProject(t, p, body.name.trim());
  }

  @Delete(':projectId') @HttpCode(204)
  remove(@Param('teamId') t: string, @Param('projectId') p: string) {
    return this.board.deleteProject(t, p);
  }
}

@Controller('teams/:teamId/projects/:projectId/tasks')
@UseGuards(BearerGuard, TeamGuard)
export class TasksController {
  constructor(private board: BoardService) {}

  @Post()
  create(@Param('teamId') t: string, @Param('projectId') p: string, @Body() body: NewTask) {
    return this.board.createTask(t, p, body.title.trim());
  }

  @Get(':taskId')
  get(@Param('teamId') t: string, @Param('projectId') p: string, @Param('taskId') k: string) {
    return this.board.getTask(t, p, k);
  }

  @Patch(':taskId')
  change(@Param('teamId') t: string, @Param('projectId') p: string,
         @Param('taskId') k: string, @Body() body: ChangeTask) {
    return this.board.updateTask(t, p, k, body);
  }

  @Delete(':taskId') @HttpCode(204)
  remove(@Param('teamId') t: string, @Param('projectId') p: string, @Param('taskId') k: string) {
    return this.board.deleteTask(t, p, k);
  }
}
