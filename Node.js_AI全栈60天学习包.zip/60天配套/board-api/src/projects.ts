import {
  BadRequestException, Body, ConflictException, Controller, Delete, Get,
  HttpCode, Injectable, NotFoundException, Param, Patch, Post, Query, UseGuards,
} from '@nestjs/common';
import { Type } from 'class-transformer';
import { IsEnum, IsInt, IsString, Matches, Max, MaxLength, Min, ValidateIf } from 'class-validator';
import { Prisma, TaskStatus } from '@prisma/client';
import { BearerGuard } from './auth';
import { TeamGuard } from './teams';
import { PrismaService } from './prisma.service';
import { BoardGateway } from './board.gateway';

function mapWriteError(error: unknown): never {
  if (error instanceof Prisma.PrismaClientKnownRequestError) {
    if (error.code === 'P2025') throw new NotFoundException('当前范围内找不到记录');
    if (error.code === 'P2003') throw new ConflictException('关联记录阻止了本次写入');
  }
  throw error;
}

const taskFields = { id: true, title: true, status: true, teamId: true, projectId: true } as const;

@Injectable()
export class BoardService {
  constructor(private db: PrismaService, private gateway: BoardGateway) {}

  async requireProject(teamId: string, projectId: string) {
    const project = await this.db.project.findUnique({ where: { id: projectId, teamId } });
    if (!project) throw new NotFoundException('项目不存在');
    return project;
  }

  listProjects(teamId: string) {
    return this.db.project.findMany({ where: { teamId }, orderBy: { id: 'asc' } });
  }

  createProject(teamId: string, name: string) {
    return this.db.project.create({ data: { teamId, name } });
  }

  renameProject(teamId: string, id: string, name: string) {
    return this.db.project.update({ where: { id, teamId }, data: { name } }).catch(mapWriteError);
  }

  async deleteProject(teamId: string, id: string) {
    await this.db.project.delete({ where: { id, teamId } }).catch(mapWriteError);
  }

  // Day50：带状态过滤与游标翻页的列表，供第 54 天前端首屏调用
  async listTasks(teamId: string, projectId: string, query: TaskListQuery) {
    await this.requireProject(teamId, projectId);
    const rows = await this.db.task.findMany({
      where: { teamId, projectId, status: query.status },
      orderBy: [{ createdAt: 'desc' }, { id: 'desc' }],
      skip: query.offset, take: query.limit + 1, select: taskFields,
    });
    const next = query.offset + query.limit;
    return {
      items: rows.slice(0, query.limit),
      nextOffset: rows.length > query.limit && next <= 10000 ? next : null,
    };
  }

  // Day53：按状态统计，SQL 的 where 同时限制 teamId 与 projectId
  async taskStats(teamId: string, projectId: string) {
    await this.requireProject(teamId, projectId);
    const rows = await this.db.$queryRaw<Array<{ status: string; count: bigint }>>`
      SELECT status::text AS status, COUNT(*)::bigint AS count
      FROM "Task"
      WHERE "teamId" = ${teamId} AND "projectId" = ${projectId}
      GROUP BY status
    `;
    return {
      todo: Number(rows.find(row => row.status === 'todo')?.count ?? 0n),
      doing: Number(rows.find(row => row.status === 'doing')?.count ?? 0n),
      done: Number(rows.find(row => row.status === 'done')?.count ?? 0n),
    };
  }

  async createTask(teamId: string, projectId: string, title: string) {
    await this.requireProject(teamId, projectId);
    const task = await this.db.task.create({
      data: { teamId, projectId, title }, select: taskFields,
    }).catch(mapWriteError);
    this.gateway.taskChanged(teamId, task.id, 'created');
    return task;
  }

  async getTask(teamId: string, projectId: string, id: string) {
    const task = await this.db.task.findUnique({
      where: { id, teamId, projectId }, select: taskFields,
    });
    if (!task) throw new NotFoundException('任务不存在');
    return task;
  }

  async updateTask(teamId: string, projectId: string, id: string, body: ChangeTask) {
    const data = { title: body.title?.trim(), status: body.status };
    if (data.title === undefined && data.status === undefined) {
      throw new BadRequestException('请提供 title 或 status');
    }
    const task = await this.db.task.update({
      where: { id, teamId, projectId }, data, select: taskFields,
    }).catch(mapWriteError);
    this.gateway.taskChanged(teamId, id, 'updated');
    return task;
  }

  async deleteTask(teamId: string, projectId: string, id: string) {
    await this.db.task.delete({ where: { id, teamId, projectId } }).catch(mapWriteError);
    this.gateway.taskChanged(teamId, id, 'deleted');
  }
}

class ProjectName {
  @IsString() @Matches(/\S/) @MaxLength(80)
  name!: string;
}

class NewTask {
  @IsString() @Matches(/\S/) @MaxLength(120)
  title!: string;
}

// Day50：列表查询参数
class TaskListQuery {
  @ValidateIf((_object, value) => value !== undefined)
  @IsEnum(TaskStatus)
  status?: TaskStatus;

  @Type(() => Number) @IsInt() @Min(1) @Max(50)
  limit = 20;

  @Type(() => Number) @IsInt() @Min(0) @Max(10000)
  offset = 0;
}

class ChangeTask {
  @ValidateIf((_object, value) => value !== undefined)
  @IsString() @Matches(/\S/) @MaxLength(120)
  title?: string;

  @ValidateIf((_object, value) => value !== undefined)
  @IsEnum(TaskStatus)
  status?: TaskStatus;
}

@Controller('teams/:teamId/projects')
@UseGuards(BearerGuard, TeamGuard)
export class ProjectsController {
  constructor(private board: BoardService) {}

  @Get()
  list(@Param('teamId') t: string) { return this.board.listProjects(t); }

  @Post()
  create(@Param('teamId') t: string, @Body() body: ProjectName) {
    return this.board.createProject(t, body.name.trim());
  }

  @Get(':projectId')
  get(@Param('teamId') t: string, @Param('projectId') p: string) {
    return this.board.requireProject(t, p);
  }

  @Patch(':projectId')
  rename(@Param('teamId') t: string, @Param('projectId') p: string, @Body() body: ProjectName) {
    return this.board.renameProject(t, p, body.name.trim());
  }

  @Delete(':projectId') @HttpCode(204)
  remove(@Param('teamId') t: string, @Param('projectId') p: string) {
    return this.board.deleteProject(t, p);
  }
}

@Controller('teams/:teamId/projects/:projectId/tasks')
@UseGuards(BearerGuard, TeamGuard)
export class TasksController {
  constructor(private board: BoardService) {}

  // Day50：无参列表；必须声明在 ':taskId' 之前
  @Get()
  list(@Param('teamId') t: string, @Param('projectId') p: string, @Query() q: TaskListQuery) {
    return this.board.listTasks(t, p, q);
  }

  // Day53：静态 stats 路由必须声明在 ':taskId' 之前，否则会被当成任务 ID
  @Get('stats')
  stats(@Param('teamId') t: string, @Param('projectId') p: string) {
    return this.board.taskStats(t, p);
  }

  @Post()
  create(@Param('teamId') t: string, @Param('projectId') p: string, @Body() body: NewTask) {
    return this.board.createTask(t, p, body.title.trim());
  }

  @Get(':taskId')
  get(@Param('teamId') t: string, @Param('projectId') p: string, @Param('taskId') k: string) {
    return this.board.getTask(t, p, k);
  }

  @Patch(':taskId')
  change(@Param('teamId') t: string, @Param('projectId') p: string,
         @Param('taskId') k: string, @Body() body: ChangeTask) {
    return this.board.updateTask(t, p, k, body);
  }

  @Delete(':taskId') @HttpCode(204)
  remove(@Param('teamId') t: string, @Param('projectId') p: string, @Param('taskId') k: string) {
    return this.board.deleteTask(t, p, k);
  }
}
