import { InjectQueue } from '@nestjs/bullmq';
import { Injectable } from '@nestjs/common';
import { Queue } from 'bullmq';
import { PrismaService } from '../prisma.service';

@Injectable()
export class NotificationsService {
  constructor(
    private readonly prisma: PrismaService,
    @InjectQueue('notifications') private readonly queue: Queue,
  ) {}

  async enqueueMany(notificationIds: string[]) {
    await this.queue.addBulk(notificationIds.map((notificationId) => ({
      name: 'task-changed',
      data: { notificationId },
      opts: {
        jobId: notificationId,
        attempts: 5,
        backoff: { type: 'exponential', delay: 1000 },
        removeOnComplete: 1000,
        removeOnFail: 5000,
      },
    })));
  }

  // 补偿扫描器：把已落库但尚未成功入队的通知重新排入
  async requeuePending(limit = 100) {
    const pending = await this.prisma.notification.findMany({
      where: { readAt: null },
      orderBy: { createdAt: 'asc' },
      take: limit,
      select: { id: true },
    });
    await this.enqueueMany(pending.map((n) => n.id));
    return pending.length;
  }
}
