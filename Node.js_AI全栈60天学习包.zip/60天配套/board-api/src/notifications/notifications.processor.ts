import { Processor, WorkerHost } from '@nestjs/bullmq';
import { Logger } from '@nestjs/common';
import { Job } from 'bullmq';
import { PrismaService } from '../prisma/prisma.service';

@Processor('notifications')
export class NotificationsProcessor extends WorkerHost {
  private readonly logger = new Logger(NotificationsProcessor.name);
  constructor(private readonly prisma: PrismaService) { super(); }

  async process(job: Job<{ notificationId: string }>) {
    const notice = await this.prisma.notification.findUnique({
      where: { id: job.data.notificationId },
    });
    if (!notice) return;
    // 本地演练只记录事件；真实邮件/adapter 留在后续单元
    this.logger.log(`notification ${notice.id} ready to deliver`);
  }
}
