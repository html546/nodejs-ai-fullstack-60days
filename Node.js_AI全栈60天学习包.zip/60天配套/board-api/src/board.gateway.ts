import {
  ConnectedSocket, MessageBody, OnGatewayConnection, SubscribeMessage,
  WebSocketGateway, WebSocketServer,
} from '@nestjs/websockets';
import { ForbiddenException, Injectable } from '@nestjs/common';
import { JwtService } from '@nestjs/jwt';
import { Server, Socket } from 'socket.io';
import { PrismaService } from './prisma.service';

@WebSocketGateway({ namespace: '/board', cors: { origin: ['http://127.0.0.1:5173'] } })
export class BoardGateway implements OnGatewayConnection {
  @WebSocketServer() server!: Server;
  constructor(private jwt: JwtService, private db: PrismaService) {}

  async handleConnection(socket: Socket) {
    try {
      const token = socket.handshake.auth?.token;
      if (typeof token !== 'string') throw new Error('missing token');
      const claims = await this.jwt.verifyAsync<{ sub: string }>(token);
      if (!claims.sub) throw new Error('missing user');
      socket.data.userId = claims.sub;
    } catch {
      socket.disconnect(true);
    }
  }

  @SubscribeMessage('team:join')
  async join(@ConnectedSocket() socket: Socket, @MessageBody() body: { teamId?: string }) {
    if (typeof body?.teamId !== 'string') throw new ForbiddenException();
    const membership = await this.db.membership.findUnique({
      where: { teamId_userId: { teamId: body.teamId, userId: socket.data.userId } },
      select: { teamId: true },
    });
    if (!membership) throw new ForbiddenException();
    await socket.join(`team:${membership.teamId}`);
    return { joined: true };
  }

  taskChanged(teamId: string, taskId: string, action: 'created' | 'updated' | 'deleted') {
    this.server.to(`team:${teamId}`).emit('task:changed', { taskId, action });
  }
}
