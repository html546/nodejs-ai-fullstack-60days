// 60天配套/board-api/prisma/seed.mjs
// 只准备团队/项目/任务的演示数据；账号请用第 48 天的注册接口创建，避免在 seed 里处理密码哈希。
// 运行：node --env-file=.env prisma/seed.mjs（需先 prisma migrate deploy）
import { PrismaClient } from '@prisma/client';

const prisma = new PrismaClient();

async function main() {
  const team = await prisma.team.upsert({
    where: { id: 'demo-team' },
    update: {},
    create: { id: 'demo-team', name: '演示甲队' },
  });
  const project = await prisma.project.upsert({
    where: { id: 'demo-project' },
    update: {},
    create: { id: 'demo-project', teamId: team.id, name: '上线准备' },
  });
  const titles = ['写验收清单', '补权限测试', '检查迁移'];
  for (const [i, title] of titles.entries()) {
    const id = `demo-task-${i + 1}`;
    await prisma.task.upsert({
      where: { id },
      update: {},
      create: { id, teamId: team.id, projectId: project.id, title, status: 'todo' },
    });
  }
  console.log(`seed ok: team=${team.id} project=${project.id} tasks=${titles.length}`);
}

main().finally(() => prisma.$disconnect());
