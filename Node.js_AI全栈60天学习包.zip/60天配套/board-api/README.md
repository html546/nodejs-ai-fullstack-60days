# 协作任务板后端（第 47–53 天源码快照）

`src/` 下的文件从主教材第 47–53 天的完整代码块抽取：`auth.ts`（登录/成员）、`teams.ts`、`projects.ts`（团队/项目/任务/统计）、`board.gateway.ts`（Socket.IO 房间）、`notifications/`（BullMQ 队列）。

**运行前提**：这些文件是 Nest 控制器/服务/网关，需要配合 `nest new` 脚手架、`prisma/schema.prisma`（第 47 天的 Team/Project/Task 模型及后续追加）、`@nestjs/websockets` + `socket.io`、`@nestjs/bullmq` + Redis，以及第 52 天的迁移。按正文第 47 天先起基础工程，再逐天加入；前端见同级的 `day54-web/`。

本机起步顺序：PG/Redis → `prisma migrate dev` → `npm run start:dev` → `npm run dev`（web）。所有请求用 Bearer 令牌，团队隔离由后端的 Membership 查询保证，不能只靠前端隐藏。
