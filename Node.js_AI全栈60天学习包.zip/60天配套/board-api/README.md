# 协作任务板后端（第 47–53 天源码快照）

`src/` 下的文件从主教材第 47–53 天的完整代码块抽取：`auth.ts`（登录/成员）、`teams.ts`、`projects.ts`、`board.gateway.ts`（Socket.IO 房间）、`prisma.service.ts`、`notifications/`（BullMQ 队列）。

`projects.ts` 已合入第 50 天的 `listTasks` + `GET .../tasks`、第 51 天的 `BoardGateway` 注入与 `taskChanged` 广播、第 53 天的 `taskStats` + `GET .../tasks/stats`；`@Get()` 与静态 `@Get('stats')` 都声明在 `@Get(':taskId')` 之前，避免被当成任务 ID。因此第 54 天前端首屏的 `GET .../tasks?limit=20&offset=0` 与第 56 天 e2e 的列表断言都有对应路由。

**网关与代理**：`board.gateway.ts` 用 `namespace:'/board'` + `path:'/socket.io'`；`day54-web/vite.config.ts` 代理 `/socket.io`（`ws:true`）与 `/api`。namespace 与握手路径是两件事，不要只代理 `/board`。

**`PrismaService` 路径**：本工程是 `src/prisma.service.ts`，`src/notifications/` 下的文件用 `../prisma.service`；博客工程的 `src/prisma/prisma.service.ts` 是另一套目录，不要混用。

## 未收录，需按正文补齐

- 脚手架：`package.json`、`tsconfig.json`、`nest-cli.json`、`main.ts`、`app.module.ts`、`.env`
- Prisma：`schema.prisma` 与迁移历史（Team/Project/Task/Membership/Notification）
- 第 52 天 `redis/redis-options.ts` 与 `BullModule.forRootAsync` 的注册代码（正文已给），以及 Redis 实例
- 第 56 天的 e2e 测试；`prisma/seed.mjs` 已在 v3 补入（团队/项目/任务演示数据，账号仍走注册接口）

**运行前提**：这些文件是 Nest 控制器/服务/网关，需要配合 `nest new` 脚手架、Prisma schema、`@nestjs/websockets` + `socket.io`、`@nestjs/bullmq` + Redis。按第 47 天先起基础工程，再逐天加入；前端见同级 `day54-web/`。

本机起步顺序：PG/Redis → `prisma migrate dev` → `npm run start:dev` → `npm run dev`（web）。所有请求用 Bearer 令牌，团队隔离由后端的 Membership 查询保证，不能只靠前端隐藏。
