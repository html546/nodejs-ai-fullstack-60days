# 第 54 天配套前端

先在此目录执行 `npm install`、`npm run build`，再 `npm run dev`。需要第 47—53 天的 Nest API 同时运行在本机 3000 端口，且已创建测试用户、团队、项目。页面不会替你创建后端，编译成功不代表数据库或 API 已通过端到端验证。

令牌只存在内存；页面刷新后需重新登录。只提供首屏任务列表、手动刷新与新增，其他功能按正文扩展。

## 版本约定

本快照锁定 `vite ^6.4.0`、`@vitejs/plugin-react ^4.7`、React 19、单份 `tsconfig.json`，构建脚本为 `tsc --noEmit && vite build`。正文第 47 天的 `npm create vite@6 -- web --template react-ts` 与此一致；若自行用更新版本的 `create vite` 生成脚手架（会得到 `tsc -b` 与拆分的 tsconfig），请以本目录的 `package.json` / `tsconfig.json` 为准再覆盖 `src/`。

`vite.config.ts` 代理 `/api` 与 `/socket.io`（`ws:true`）：网关 `namespace:'/board'` 是命名空间，Socket.IO 握手端点固定为 `/socket.io/`，不要改回只代理 `/board`。`src/api.ts` 的 `io('/board', { path:'/socket.io' })` 与之对应。
