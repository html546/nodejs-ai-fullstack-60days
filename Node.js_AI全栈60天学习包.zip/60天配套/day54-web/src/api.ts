// web/src/api.ts
import { io, type Socket } from 'socket.io-client';

export type Task = {
  id: string; title: string; status: 'todo' | 'doing' | 'done';
  teamId: string; projectId: string;
};
let token: string | undefined;
export function setToken(value?: string) { token = value; }
export function getToken() { return token; }

async function request<T>(path: string, init: RequestInit = {}): Promise<T> {
  const response = await fetch(`/api${path}`, {
    ...init,
    headers: {
      'Content-Type': 'application/json',
      ...(token ? { Authorization: `Bearer ${token}` } : {}),
      ...init.headers,
    },
  });
  if (!response.ok) {
    const data = await response.json().catch(() => ({}));
    throw new Error(data.message ?? `请求失败（${response.status}）`);
  }
  return response.status === 204 ? undefined as T : response.json();
}
export const api = {
  login: (email: string, password: string) => request<{ accessToken: string }>('/auth/login', {
    method: 'POST', body: JSON.stringify({ email, password }),
  }),
  teams: () => request<Array<{ id: string; name: string; role: string }>>('/teams'),
  projects: (teamId: string) => request<Array<{ id: string; name: string }>>(
    `/teams/${encodeURIComponent(teamId)}/projects`,
  ),
  tasks: (teamId: string, projectId: string) => request<{ items: Task[]; nextOffset: number | null }>(
    `/teams/${encodeURIComponent(teamId)}/projects/${encodeURIComponent(projectId)}/tasks?limit=20&offset=0`,
  ),
  createTask: (teamId: string, projectId: string, title: string) => request<Task>(
    `/teams/${encodeURIComponent(teamId)}/projects/${encodeURIComponent(projectId)}/tasks`,
    { method: 'POST', body: JSON.stringify({ title }) },
  ),
};

let socket: Socket | undefined;
export function connectBoard(
  teamId: string,
  onTaskChanged: () => void,
  onError: (message: string) => void,
) {
  socket?.disconnect();
  const next = io('/board', {
    path: '/socket.io',
    auth: { token: getToken() ?? '' },
    transports: ['websocket'],
  });
  socket = next;
  next.on('connect', () => next.emit('team:join', { teamId }));
  next.on('connect_error', (error) => onError(error.message));
  next.on('task:changed', onTaskChanged);
  return () => {
    next.off('task:changed', onTaskChanged);
    next.disconnect();
    if (socket === next) socket = undefined;
  };
}
