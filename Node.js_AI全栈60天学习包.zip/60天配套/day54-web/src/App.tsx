// web/src/App.tsx，完整替换
import { useRef, useState, type FormEvent } from 'react';
import { api, setToken, type Task } from './api';
import './App.css';

type Team = { id: string; name: string; role: string };
type Project = { id: string; name: string };

export default function App() {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [signedIn, setSignedIn] = useState(false);
  const [teams, setTeams] = useState<Team[]>([]);
  const [projects, setProjects] = useState<Project[]>([]);
  const [teamId, setTeamId] = useState('');
  const [projectId, setProjectId] = useState('');
  const [title, setTitle] = useState('');
  const [tasks, setTasks] = useState<Task[]>([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const sequence = useRef(0);

  async function perform(operation: (id: number) => Promise<void>) {
    const id = ++sequence.current;
    setError('');
    setLoading(true);
    try { await operation(id); }
    catch (reason) {
      if (id === sequence.current) {
        setError(reason instanceof Error ? reason.message : '请求失败');
      }
    } finally {
      if (id === sequence.current) setLoading(false);
    }
  }

  async function loadProject(team: string, project: string, id: number) {
    setProjectId(project);
    setTasks([]);
    if (!project) return;
    const page = await api.tasks(team, project);
    if (id === sequence.current) setTasks(page.items);
  }

  async function loadTeam(team: string, id: number) {
    setTeamId(team);
    setProjectId('');
    setProjects([]);
    setTasks([]);
    if (!team) return;
    const nextProjects = await api.projects(team);
    if (id !== sequence.current) return;
    setProjects(nextProjects);
    await loadProject(team, nextProjects[0]?.id ?? '', id);
  }

  async function signIn(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    await perform(async (id) => {
      setToken();
      setSignedIn(false);
      const result = await api.login(email, password);
      if (id !== sequence.current) return;
      setToken(result.accessToken);
      setPassword('');
      setSignedIn(true);
      const nextTeams = await api.teams();
      if (id !== sequence.current) return;
      setTeams(nextTeams);
      await loadTeam(nextTeams[0]?.id ?? '', id);
    });
  }

  async function addTask(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    await perform(async (id) => {
      await api.createTask(teamId, projectId, title.trim());
      if (id !== sequence.current) return;
      setTitle('');
      await loadProject(teamId, projectId, id);
    });
  }

  function signOut() {
    ++sequence.current;
    setToken();
    setSignedIn(false);
    setTeams([]);
    setProjects([]);
    setTeamId('');
    setProjectId('');
    setTasks([]);
    setTitle('');
    setPassword('');
    setError('');
    setLoading(false);
  }

  return <main className="board">
    <h1>协作任务板</h1>
    {!signedIn ? <form onSubmit={signIn}>
      <label>邮箱<input type="email" autoComplete="username" required
        value={email} onChange={event => setEmail(event.target.value)} /></label>
      <label>密码<input type="password" autoComplete="current-password" required
        value={password} onChange={event => setPassword(event.target.value)} /></label>
      <button disabled={loading}>登录</button>
    </form> : <>
      <button onClick={signOut}>退出本机登录</button>
      <p>刷新页面后需重新登录；这里只显示当前项目的前 20 条任务。</p>
      <label>团队<select disabled={loading} value={teamId}
        onChange={event => void perform(id => loadTeam(event.target.value, id))}>
        <option value="">请选择团队</option>
        {teams.map(team => <option key={team.id} value={team.id}>{team.name}</option>)}
      </select></label>
      {!loading && !error && teams.length === 0 && <p>尚未加入团队，请先完成第 48 天。</p>}
      <label>项目<select disabled={loading || !teamId} value={projectId}
        onChange={event => {
          const project = event.target.value;
          void perform(id => loadProject(teamId, project, id));
        }}>
        <option value="">请选择项目</option>
        {projects.map(project => <option key={project.id} value={project.id}>{project.name}</option>)}
      </select></label>
      {!loading && !error && teamId && projects.length === 0 && <p>该团队暂无项目，请先完成第 49 天。</p>}
      <form onSubmit={addTask}>
        <label>新任务<input value={title} maxLength={120}
          onChange={event => setTitle(event.target.value)} /></label>
        <button disabled={loading || !projectId || !title.trim()}>新增任务</button>
      </form>
      <button disabled={loading || !projectId}
        onClick={() => void perform(id => loadProject(teamId, projectId, id))}>刷新任务</button>
      {!loading && !error && projectId && tasks.length === 0 && <p>目前没有任务。</p>}
      {!loading && !error && tasks.length > 0 && <ul>
        {tasks.map(task => <li key={task.id}>[{task.status}] {task.title}</li>)}
      </ul>}
    </>}
    {loading && <p role="status">正在请求，请稍候……</p>}
    {error && <p role="alert">{error}</p>}
  </main>;
}
